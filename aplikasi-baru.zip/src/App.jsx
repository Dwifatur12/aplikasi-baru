import React, { useState, useEffect, useRef } from 'react';
import { 
  Shield, Video, Users, Calendar, Clock, Phone, FileText, 
  CheckCircle2, AlertCircle, X, Search, Filter, LogIn, LogOut,
  Moon, Sun, ChevronRight, Activity, MessageSquare, Trash2,
  Check, PhoneCall, Info, UserCheck, Loader2, Download, Database,
  Upload, Printer, FileDown, Settings
} from 'lucide-react';

// ==========================================
// KONFIGURASI DATABASE & FIREBASE
// ==========================================
import { initializeApp } from 'firebase/app';
import { getAuth, signInWithCustomToken, signInAnonymously, onAuthStateChanged } from 'firebase/auth';
import { getFirestore, collection, addDoc, onSnapshot, doc, updateDoc, deleteDoc, query, orderBy } from 'firebase/firestore';

const firebaseConfig = typeof __firebase_config !== 'undefined' ? JSON.parse(__firebase_config) : {
  apiKey: "mock-key", authDomain: "mock.firebaseapp.com", projectId: "mock-id"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const appId = typeof __app_id !== 'undefined' ? __app_id : 'sitaba-kalabahi-v1';

// ==========================================
// FUNGSI HELPER GLOBAL
// ==========================================
const formatDateIndo = (date) => {
  return new Intl.DateTimeFormat('id-ID', {
    timeZone: 'Asia/Makassar', weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
  }).format(new Date(date));
};

const formatPhoneWA = (phone) => {
  let cleaned = ('' + phone).replace(/\D/g, '');
  if (cleaned.startsWith('0')) cleaned = '62' + cleaned.substring(1);
  return cleaned;
};

const formatLiveTime = (date) => {
  const optionsDate = { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' };
  const optionsTime = { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false };
  return `${new Intl.DateTimeFormat('id-ID', optionsDate).format(date)} - ${new Intl.DateTimeFormat('id-ID', optionsTime).format(date)} WITA`;
};

// ==========================================
// KOMPONEN UTAMA
// ==========================================
export default function App() {
  const [firebaseUser, setFirebaseUser] = useState(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(() => localStorage.getItem('darkMode') !== 'false');
  const [toast, setToast] = useState(null);
  
  // State Navigasi
  const [currentView, setCurrentView] = useState('public'); 
  const [adminUser, setAdminUser] = useState(() => {
    const saved = localStorage.getItem('sitabaAdmin');
    return saved ? JSON.parse(saved) : null;
  });

  const [dataKunjungan, setDataKunjungan] = useState([]);
  const [masterWbp, setMasterWbp] = useState([]); 
  
  const [currentTime, setCurrentTime] = useState(new Date());
  const [showSettings, setShowSettings] = useState(false);
  const [credForm, setCredForm] = useState({ username: '', password: '' });

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  useEffect(() => {
    if (isDarkMode) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
    localStorage.setItem('darkMode', isDarkMode);
  }, [isDarkMode]);

  // Efek Jam Live
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Manajemen Akses Admin
  const getAdminCreds = () => {
    const creds = localStorage.getItem('sapaAdminCreds');
    return creds ? JSON.parse(creds) : { username: 'kalabahi', password: 'pastiwbk' };
  };

  const handleSaveCreds = (e) => {
    e.preventDefault();
    localStorage.setItem('sapaAdminCreds', JSON.stringify(credForm));
    setShowSettings(false);
    showToast("Username dan Password berhasil diubah!");
  };

  const openSettings = () => {
    setCredForm(getAdminCreds());
    setShowSettings(true);
  };

  // Auth Initialization
  useEffect(() => {
    const initAuth = async () => {
      try {
        if (typeof __initial_auth_token !== 'undefined' && __initial_auth_token) {
          await signInWithCustomToken(auth, __initial_auth_token);
        } else {
          await signInAnonymously(auth);
        }
      } catch (e) { console.error("Auth failed", e); }
    };
    initAuth();
    const unsubscribe = onAuthStateChanged(auth, (user) => { 
      setFirebaseUser(user); 
      setIsAuthReady(true); 
    });
    return () => unsubscribe();
  }, []);

  // Fetch Data
  useEffect(() => {
    if (!firebaseUser) return;
    const unsubKunjungan = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'kunjungan'), (snap) => {
      const data = snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => b.timestamp - a.timestamp);
      setDataKunjungan(data);
    });
    
    const unsubWbp = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'wbp'), (snap) => {
      const data = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setMasterWbp(data);
    });
    
    return () => { unsubKunjungan(); unsubWbp(); };
  }, [firebaseUser]);

  if (!isAuthReady) {
    return <div className="min-h-screen flex items-center justify-center bg-slate-950"><Video size={60} className="text-emerald-500 animate-pulse" /></div>;
  }

  return (
    <div className="min-h-screen bg-[#f8fafc] dark:bg-[#0b1120] text-slate-950 dark:text-slate-100 transition-colors duration-500 font-sans selection:bg-emerald-500/30 overflow-x-hidden relative">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@200;400;600;800&display=swap');
        * { font-family: 'Plus Jakarta Sans', sans-serif; }
        
        .glass-card { 
          background: rgba(255, 255, 255, 0.65); 
          backdrop-filter: blur(24px); 
          -webkit-backdrop-filter: blur(24px);
          border: 1px solid rgba(255, 255, 255, 0.8); 
          box-shadow: 0 25px 50px -12px rgba(0,0,0,0.05), 0 0 0 1px rgba(0,0,0,0.02) inset; 
        }
        .dark .glass-card { 
          background: rgba(15, 23, 42, 0.5); 
          border: 1px solid rgba(255, 255, 255, 0.08); 
          box-shadow: 0 25px 50px -12px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.02) inset; 
        }
        
        .btn-3d { 
          transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275); 
          box-shadow: 0 6px 0 rgba(16, 185, 129, 0.6), 0 15px 20px rgba(16, 185, 129, 0.3); 
        }
        .btn-3d:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 0 rgba(16, 185, 129, 0.6), 0 20px 25px rgba(16, 185, 129, 0.4);
        }
        .btn-3d:active { 
          transform: translateY(4px); 
          box-shadow: 0 2px 0 rgba(16, 185, 129, 0.6), 0 5px 10px rgba(16, 185, 129, 0.2); 
        }
        
        .btn-3d-blue { 
          transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275); 
          box-shadow: 0 6px 0 rgba(37, 99, 235, 0.6), 0 15px 20px rgba(37, 99, 235, 0.3); 
        }
        .btn-3d-blue:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 0 rgba(37, 99, 235, 0.6), 0 20px 25px rgba(37, 99, 235, 0.4);
        }
        .btn-3d-blue:active { 
          transform: translateY(4px); 
          box-shadow: 0 2px 0 rgba(37, 99, 235, 0.6), 0 5px 10px rgba(37, 99, 235, 0.2); 
        }

        .premium-input {
          background: rgba(255, 255, 255, 0.8);
          border: 1px solid rgba(226, 232, 240, 0.8);
          box-shadow: inset 0 2px 4px rgba(0,0,0,0.02);
        }
        .dark .premium-input {
          background: rgba(15, 23, 42, 0.6);
          border: 1px solid rgba(51, 65, 85, 0.5);
          box-shadow: inset 0 2px 4px rgba(0,0,0,0.2);
        }
        .premium-input:focus {
          border-color: #10b981;
          box-shadow: 0 0 0 4px rgba(16, 185, 129, 0.15), inset 0 2px 4px rgba(0,0,0,0.02);
          background: #ffffff;
        }
        .dark .premium-input:focus {
          border-color: #10b981;
          box-shadow: 0 0 0 4px rgba(16, 185, 129, 0.15), inset 0 2px 4px rgba(0,0,0,0.2);
          background: #0f172a;
        }

        .text-gradient-animate {
          background-size: 200% auto;
          animation: textShine 4s linear infinite;
        }
        @keyframes textShine {
          to { background-position: 200% center; }
        }

        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
        .dark ::-webkit-scrollbar-thumb { background: #334155; }
        ::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
        .dark ::-webkit-scrollbar-thumb:hover { background: #475569; }

        input[type="date"]::-webkit-calendar-picker-indicator, input[type="time"]::-webkit-calendar-picker-indicator { cursor: pointer; filter: brightness(0); opacity: 0.5; transition: all 0.3s; }
        .dark input[type="date"]::-webkit-calendar-picker-indicator, .dark input[type="time"]::-webkit-calendar-picker-indicator { filter: brightness(0) invert(1); opacity: 0.8; }
        input[type="date"]::-webkit-calendar-picker-indicator:hover, input[type="time"]::-webkit-calendar-picker-indicator:hover { opacity: 1; transform: scale(1.1); }
      `}</style>

      {/* DYNAMIC BACKGROUND BLOBS */}
      <div className="fixed top-[-10%] left-[-10%] w-[50vw] h-[50vw] max-w-[600px] max-h-[600px] bg-emerald-400/20 dark:bg-emerald-600/10 rounded-full blur-[100px] -z-10 animate-pulse pointer-events-none mix-blend-multiply dark:mix-blend-lighten" style={{animationDuration: '8s'}}></div>
      <div className="fixed bottom-[-10%] right-[-5%] w-[60vw] h-[60vw] max-w-[700px] max-h-[700px] bg-blue-400/20 dark:bg-blue-600/10 rounded-full blur-[120px] -z-10 animate-pulse pointer-events-none mix-blend-multiply dark:mix-blend-lighten" style={{animationDuration: '10s'}}></div>

      {/* GLOBAL TOAST */}
      {toast && (
        <div className={`fixed top-6 left-1/2 -translate-x-1/2 z-[300] px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-3 animate-in slide-in-from-top-10 fade-in duration-300 backdrop-blur-md border ${toast.type === 'error' ? 'bg-rose-600/90 border-rose-500 text-white' : 'bg-emerald-600/90 border-emerald-500 text-white'}`}>
          {toast.type === 'error' ? <AlertCircle size={22}/> : <CheckCircle2 size={22}/>}
          <span className="text-xs font-bold uppercase tracking-widest text-white">{toast.message}</span>
        </div>
      )}

      {/* HEADER GLOBAL */}
      <header className="fixed top-0 left-0 right-0 z-50 px-6 py-4 flex justify-between items-center pointer-events-none transition-all">
        <div className="glass-card px-5 py-3 rounded-2xl pointer-events-auto flex items-center gap-3 shadow-lg hover:shadow-xl transition-shadow">
          <div className="p-1.5 bg-emerald-100 dark:bg-emerald-900/40 rounded-xl">
            <Video className="text-emerald-600 dark:text-emerald-400" size={20} />
          </div>
          <span className="font-black tracking-tighter text-[15px] bg-clip-text text-transparent bg-gradient-to-r from-emerald-600 to-blue-600 dark:from-emerald-400 dark:to-blue-400">SAPA KALABAHI</span>
        </div>
        <div className="flex gap-3 pointer-events-auto items-center">
          <div className="hidden sm:flex items-center gap-2 px-4 py-2.5 glass-card rounded-full text-[10px] font-black uppercase tracking-widest text-slate-600 dark:text-slate-300 mr-2 shadow-sm border border-emerald-500/10">
            <Clock size={14} className="text-blue-500" />
            {formatLiveTime(currentTime)}
          </div>
          <button onClick={() => setIsDarkMode(!isDarkMode)} className="p-3.5 glass-card rounded-2xl hover:scale-105 hover:shadow-lg transition-all text-slate-600 dark:text-slate-300 border border-transparent hover:border-slate-300 dark:hover:border-slate-700">
            {isDarkMode ? <Sun size={18} className="text-amber-400"/> : <Moon size={18} className="text-indigo-600"/>}
          </button>
          {currentView === 'public' && !adminUser && (
            <button onClick={() => setCurrentView('admin-login')} className="p-3.5 glass-card rounded-2xl hover:scale-105 hover:shadow-lg transition-all text-blue-600 dark:text-blue-400 border border-transparent hover:border-blue-200 dark:hover:border-blue-900/50" title="Login Petugas">
              <Shield size={18} />
            </button>
          )}
          {adminUser && currentView !== 'public' && (
            <>
              <button onClick={openSettings} className="p-3.5 glass-card rounded-2xl hover:scale-105 hover:shadow-lg transition-all text-slate-600 dark:text-slate-300 border border-transparent hover:border-slate-300 dark:hover:border-slate-700" title="Ubah Akun Petugas">
                <Settings size={18} />
              </button>
              <button onClick={() => { localStorage.removeItem('sitabaAdmin'); setAdminUser(null); setCurrentView('public'); showToast("Berhasil Keluar"); }} className="p-3.5 bg-rose-50 text-rose-600 border border-rose-200 dark:bg-rose-900/20 dark:border-rose-900/50 dark:text-rose-400 rounded-2xl hover:scale-105 hover:bg-rose-100 dark:hover:bg-rose-900/40 transition-all shadow-sm" title="Keluar dari Dashboard">
                <LogOut size={18} />
              </button>
            </>
          )}
        </div>
      </header>

      <div className="pt-24 pb-12 px-6 min-h-screen relative z-10">
        {currentView === 'public' && <PublicPortal db={db} appId={appId} showToast={showToast} firebaseUser={firebaseUser} dataKunjungan={dataKunjungan} masterWbp={masterWbp} />}
        {currentView === 'admin-login' && <AdminLogin onLogin={(u) => { setAdminUser(u); localStorage.setItem('sitabaAdmin', JSON.stringify(u)); setCurrentView('admin-dashboard'); showToast("Login Berhasil"); }} onBack={() => setCurrentView('public')} showToast={showToast} getAdminCreds={getAdminCreds} />}
        {currentView === 'admin-dashboard' && <AdminDashboard dataKunjungan={dataKunjungan} db={db} appId={appId} showToast={showToast} masterWbp={masterWbp} />}

        {/* MODAL UBAH AKUN PETUGAS */}
        {showSettings && (
          <div className="fixed inset-0 z-[600] flex items-center justify-center p-6 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="glass-card p-8 rounded-3xl w-full max-w-sm shadow-2xl relative border border-white/20 dark:border-slate-700/50">
              <button onClick={() => setShowSettings(false)} className="absolute top-6 right-6 p-2 text-slate-500 hover:text-rose-500 transition-colors"><X size={16}/></button>
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center mb-4">
                <Settings size={24} className="text-blue-600 dark:text-blue-400"/>
              </div>
              <h3 className="text-lg font-black mb-1 text-slate-900 dark:text-white">Pengaturan Akun</h3>
              <p className="text-[10px] font-bold text-slate-500 mb-6 uppercase tracking-widest">Ubah Akses Login Petugas</p>
              
              <form onSubmit={handleSaveCreds} className="space-y-4 text-left">
                <div className="space-y-1">
                  <label className="text-[10px] font-black uppercase text-slate-500 ml-1">Username Baru</label>
                  <input type="text" value={credForm.username} onChange={e=>setCredForm({...credForm, username: e.target.value})} className="w-full px-4 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-bold outline-none focus:border-blue-500 transition-colors" required />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black uppercase text-slate-500 ml-1">Password Baru</label>
                  <input type="text" value={credForm.password} onChange={e=>setCredForm({...credForm, password: e.target.value})} className="w-full px-4 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-bold outline-none focus:border-blue-500 transition-colors" required />
                </div>
                <div className="flex gap-3 pt-4">
                  <button type="button" onClick={() => setShowSettings(false)} className="flex-1 py-3 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-black uppercase text-[10px] tracking-widest hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors">Batal</button>
                  <button type="submit" className="flex-1 py-3 bg-blue-600 text-white rounded-xl font-black uppercase text-[10px] tracking-widest hover:bg-blue-700 transition-colors shadow-md shadow-blue-600/20">Simpan</button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ==========================================
// VIEW: PORTAL PUBLIK (FORM PENDAFTARAN)
// ==========================================
function PublicPortal({ db, appId, showToast, firebaseUser, dataKunjungan, masterWbp }) {
  const [formData, setFormData] = useState({
    namaPengunjung: '', nik: '', noWa: '', alamat: '', namaWbp: '', hubungan: '', tanggal: '', sesi: ''
  });
  const [ktpFile, setKtpFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [successData, setSuccessData] = useState(null);
  const [showCekStatus, setShowCekStatus] = useState(false);
  const [cekId, setCekId] = useState('');
  const [cekResult, setCekResult] = useState(null);

  const handleCekStatus = () => {
    if (!cekId) return;
    const found = dataKunjungan.find(d => d.id.slice(-6).toUpperCase() === cekId.toUpperCase());
    if (found) setCekResult(found);
    else showToast("Kode Antrean tidak ditemukan", "error");
  };

  const handleDateChange = (e) => {
    const selectedDate = new Date(e.target.value);
    if (selectedDate.getDay() === 0) {
      showToast("Hari Minggu libur pelayanan. Silakan pilih hari lain.", "error");
      setFormData({...formData, tanggal: '', sesi: ''});
    } else {
      setFormData({...formData, tanggal: e.target.value, sesi: ''});
    }
  };

  const getSesiOptions = (tanggalStr) => {
    if (!tanggalStr) return [];
    const date = new Date(tanggalStr);
    const day = date.getDay();
    if (day === 0) return []; 
    let options = (day === 5) ? ['08:00', '08:30', '09:00', '09:30', '10:00', '10:30'] : ['08:00', '08:30', '09:00', '09:30', '10:00', '10:30', '11:00', '11:30'];
    return options;
  };

  const availableSesi = getSesiOptions(formData.tanggal);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 800000) return showToast("Ukuran foto maksimal 800KB", "error");
      const reader = new FileReader();
      reader.onloadend = () => setKtpFile(reader.result);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!firebaseUser) return showToast("Sistem belum siap, tunggu sebentar.", "error");
    if (!ktpFile) return showToast("Harap lampirkan foto KTP/Identitas", "error");
    if (formData.nik.length !== 16) return showToast("NIK wajib 16 digit angka", "error");
    
    const kuotaTerpakai = dataKunjungan.filter(d => d.tanggal === formData.tanggal && d.sesi === formData.sesi && d.status !== 'Ditolak').length;
    if (kuotaTerpakai >= 10) return showToast("Kapasitas sesi ini penuh. Silakan pilih jadwal lain.", "error");

    setLoading(true);
    try {
      const payload = {
        ...formData,
        ktpBase64: ktpFile,
        status: 'Menunggu',
        timestamp: Date.now(),
        tanggalFormat: formatDateIndo(formData.tanggal)
      };
      const docRef = await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'kunjungan'), payload);
      setSuccessData({ id: docRef.id.slice(-6).toUpperCase(), ...payload });
      setFormData({ namaPengunjung: '', nik: '', noWa: '', alamat: '', namaWbp: '', hubungan: '', tanggal: '', sesi: '' });
      setKtpFile(null);
    } catch (err) {
      showToast("Gagal mengirim pendaftaran", "error");
    } finally {
      setLoading(false);
    }
  };

  if (successData) {
    return (
      <div className="max-w-md mx-auto mt-10 animate-in zoom-in duration-500">
        <div className="glass-card p-10 rounded-[3rem] text-center border-emerald-500/30">
          <CheckCircle2 size={50} className="text-emerald-500 mx-auto mb-4" />
          <h2 className="text-2xl font-black mb-2 text-slate-900 dark:text-white">Pendaftaran Berhasil!</h2>
          <div className="bg-slate-100 dark:bg-slate-800 p-6 rounded-2xl mb-6">
            <p className="text-[10px] font-black uppercase text-slate-400 mb-1">Kode Antrean Anda</p>
            <p className="text-4xl font-black text-emerald-600 tracking-widest">{successData.id}</p>
          </div>
          <button onClick={() => setSuccessData(null)} className="w-full py-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl font-black uppercase text-[11px] tracking-widest">Selesai</button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center min-h-[80vh]">
      <div className="lg:col-span-5 space-y-8 animate-in slide-in-from-left duration-700">
        <h1 className="text-5xl lg:text-7xl font-black tracking-tighter leading-[1.05] text-slate-900 dark:text-white">
          SAPA <br/>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-500 to-blue-600">KALABAHI</span>
        </h1>
        <p className="font-semibold text-slate-600 dark:text-slate-400">Pendaftaran Kunjungan Virtual Video Call untuk Keluarga WBP Lapas Kelas IIB Kalabahi.</p>
        <button onClick={() => { setShowCekStatus(true); setCekResult(null); }} className="px-6 py-3 bg-white dark:bg-slate-900 text-blue-600 rounded-full text-xs font-black uppercase tracking-widest border border-blue-100 shadow-sm flex items-center gap-2">
          <Search size={16}/> Cek Status Pendaftaran
        </button>
      </div>

      <div className="lg:col-span-7 animate-in slide-in-from-right duration-700">
        <div className="glass-card p-8 md:p-10 rounded-[2.5rem] relative">
          <h2 className="text-2xl font-black mb-8 flex items-center gap-3"><UserCheck className="text-emerald-500"/> Registrasi Pengunjung</h2>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input type="text" placeholder="Nama Lengkap" value={formData.namaPengunjung} onChange={e=>setFormData({...formData, namaPengunjung: e.target.value.toUpperCase()})} className="px-5 py-4 premium-input rounded-2xl text-xs font-bold uppercase outline-none" required />
              <input type="number" placeholder="16 Digit NIK KTP" value={formData.nik} onChange={e=>setFormData({...formData, nik: e.target.value.slice(0,16)})} className="px-5 py-4 premium-input rounded-2xl text-xs font-bold outline-none" required />
              <input type="number" placeholder="Nomor WhatsApp (08...)" value={formData.noWa} onChange={e=>setFormData({...formData, noWa: e.target.value})} className="px-5 py-4 premium-input rounded-2xl text-xs font-bold outline-none" required />
              <select value={formData.hubungan} onChange={e=>setFormData({...formData, hubungan: e.target.value})} className="px-5 py-4 premium-input rounded-2xl text-xs font-bold outline-none" required>
                <option value="">-- Hubungan --</option>
                <option value="Orang Tua">Orang Tua</option><option value="Suami / Istri">Suami / Istri</option><option value="Anak">Anak</option><option value="Saudara">Saudara</option><option value="Lainnya">Lainnya</option>
              </select>
            </div>
            <input type="text" placeholder="Alamat Domisili Lengkap" value={formData.alamat} onChange={e=>setFormData({...formData, alamat: e.target.value})} className="w-full px-5 py-4 premium-input rounded-2xl text-xs font-bold outline-none" required />
            <input list="wbp-list" placeholder="Nama Warga Binaan (WBP)" value={formData.namaWbp} onChange={e=>setFormData({...formData, namaWbp: e.target.value.toUpperCase()})} className="w-full px-5 py-4 premium-input rounded-2xl text-xs font-bold outline-none uppercase" required />
            <datalist id="wbp-list">{masterWbp.map(w => <option key={w.id} value={w.nama} />)}</datalist>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input type="date" value={formData.tanggal} min={new Date().toISOString().split('T')[0]} onChange={handleDateChange} className="px-5 py-4 premium-input rounded-2xl text-xs font-bold outline-none" required />
              <select value={formData.sesi} onChange={e=>setFormData({...formData, sesi: e.target.value})} disabled={!formData.tanggal} className="px-5 py-4 premium-input rounded-2xl text-xs font-bold outline-none" required>
                <option value="">Pilih Jam</option>
                {availableSesi.map(s => <option key={s} value={`${s} WITA`}>{s} WITA</option>)}
              </select>
            </div>
            <div className="relative">
              <input type="file" accept="image/*" onChange={handleFileChange} id="ktp" className="hidden" required />
              <label htmlFor="ktp" className={`w-full py-6 border-2 border-dashed rounded-2xl flex flex-col items-center justify-center cursor-pointer transition-all ${ktpFile ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950 text-emerald-600' : 'border-slate-300 text-slate-500'}`}>
                <Upload size={24} className="mb-2"/>
                <span className="text-[10px] font-black uppercase tracking-widest">{ktpFile ? '✓ Foto KTP Terlampir' : 'Unggah Foto KTP / Identitas'}</span>
              </label>
            </div>
            <button type="submit" disabled={loading} className="w-full py-5 bg-emerald-600 text-white rounded-2xl font-black uppercase text-[11px] tracking-widest btn-3d flex justify-center items-center gap-2">
              {loading ? <Loader2 className="animate-spin" size={20}/> : <><Check size={18}/> Kirim Pendaftaran</>}
            </button>
          </form>
        </div>
      </div>

      {showCekStatus && (
        <div className="fixed inset-0 z-[500] flex items-center justify-center p-6 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="glass-card p-10 rounded-[2.5rem] w-full max-w-sm relative text-center">
            <button onClick={() => setShowCekStatus(false)} className="absolute top-6 right-6 text-slate-500"><X size={20}/></button>
            <h3 className="text-xl font-black mb-6">Cek Status</h3>
            <input type="text" placeholder="Kode 6 Digit" value={cekId} onChange={e=>setCekId(e.target.value.toUpperCase())} maxLength={6} className="w-full px-5 py-4 premium-input rounded-xl text-center text-xl font-black tracking-widest mb-4" />
            <button onClick={handleCekStatus} className="w-full py-4 bg-blue-600 text-white rounded-xl font-black uppercase text-[10px] tracking-widest mb-6">Cari</button>
            {cekResult && (
              <div className="text-left p-4 bg-slate-50 dark:bg-slate-900 rounded-xl space-y-2 border border-slate-200">
                <p className="text-[10px] font-black text-slate-400 uppercase">Status Anda:</p>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-black">{cekResult.namaPengunjung}</span>
                  <span className={`px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest ${cekResult.status === 'Menunggu' ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700'}`}>{cekResult.status}</span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ==========================================
// VIEW: LOGIN ADMIN
// ==========================================
function AdminLogin({ onLogin, onBack, showToast, getAdminCreds }) {
  const [u, setU] = useState('');
  const [p, setP] = useState('');
  const handleSubmit = (e) => {
    e.preventDefault();
    const creds = getAdminCreds();
    if (u === creds.username && p === creds.password) onLogin({ username: u });
    else showToast("Kredensial Salah", "error");
  };
  return (
    <div className="min-h-[70vh] flex items-center justify-center animate-in zoom-in duration-500">
      <div className="glass-card p-10 rounded-[2.5rem] w-full max-w-sm text-center relative">
        <button onClick={onBack} className="absolute top-6 left-6 text-slate-400"><X size={20}/></button>
        <Shield size={48} className="text-blue-600 mx-auto mb-6" />
        <h2 className="text-2xl font-black mb-8">Login Petugas</h2>
        <form onSubmit={handleSubmit} className="space-y-4 text-left">
          <input type="text" placeholder="Username" value={u} onChange={e=>setU(e.target.value)} className="w-full px-5 py-4 premium-input rounded-xl font-bold" required />
          <input type="password" placeholder="Password" value={p} onChange={e=>setP(e.target.value)} className="w-full px-5 py-4 premium-input rounded-xl font-bold" required />
          <button type="submit" className="w-full py-4 bg-blue-600 text-white rounded-xl font-black uppercase text-[10px] tracking-widest btn-3d-blue mt-4">Masuk Dashboard</button>
        </form>
      </div>
    </div>
  );
}

// ==========================================
// VIEW: DASHBOARD ADMIN
// ==========================================
function AdminDashboard({ dataKunjungan, db, appId, showToast, masterWbp }) {
  const [view, setView] = useState('kunjungan');
  const [activeTab, setActiveTab] = useState('Menunggu'); 
  const [selectedPhoto, setSelectedPhoto] = useState(null); 
  const [confirm, setConfirm] = useState({ isOpen: false, msg: '', onYes: null });
  const [newWbp, setNewWbp] = useState({ nama: '', status: 'Narapidana' });

  const filteredData = dataKunjungan.filter(d => d.status === activeTab);

  const handleDeleteKunjungan = (id) => {
    setConfirm({ isOpen: true, msg: "Hapus permanen data kunjungan ini?", onYes: async () => {
      await deleteDoc(doc(db, 'artifacts', appId, 'public', 'data', 'kunjungan', id));
      showToast("Data Dihapus");
      setConfirm({ isOpen: false, msg: '', onYes: null });
    }});
  };

  const handleUpdateStatus = async (id, s) => {
    await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'kunjungan', id), { status: s });
    showToast(`Status: ${s}`);
  };

  const handlePrint = () => {
    const w = window.open('', '_blank');
    let h = `<html><head><title>Cetak Laporan</title><style>table{width:100%;border-collapse:collapse;font-family:sans-serif;font-size:12px;}th,td{border:1px solid #000;padding:8px;text-align:left;}</style></head><body><h2>Laporan Kunjungan Virtual</h2><table><tr><th>No</th><th>Tanggal</th><th>Pengunjung</th><th>Alamat</th><th>WBP</th><th>Status</th></tr>`;
    filteredData.forEach((d, i) => h += `<tr><td>${i+1}</td><td>${d.tanggalFormat}</td><td>${d.namaPengunjung}</td><td>${d.alamat || '-'}</td><td>${d.namaWbp}</td><td>${d.status}</td></tr>`);
    h += `</table><script>window.onload=()=>window.print();</script></body></html>`;
    w.document.write(h); w.document.close();
  };

  const handleAddWbp = async (e) => {
    e.preventDefault();
    if (!newWbp.nama) return;
    await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'wbp'), { ...newWbp, nama: newWbp.nama.toUpperCase() });
    setNewWbp({ nama: '', status: 'Narapidana' });
    showToast("WBP Ditambahkan");
  };

  const handleDeleteWbp = (id) => {
    setConfirm({ isOpen: true, msg: "Hapus WBP ini dari database?", onYes: async () => {
      await deleteDoc(doc(db, 'artifacts', appId, 'public', 'data', 'wbp', id));
      showToast("WBP Dihapus");
      setConfirm({ isOpen: false, msg: '', onYes: null });
    }});
  };

  return (
    <div className="animate-in fade-in duration-700">
      <div className="flex gap-4 mb-8 glass-card p-2 rounded-2xl w-fit">
        <button onClick={()=>setView('kunjungan')} className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest ${view==='kunjungan'?'bg-blue-600 text-white shadow-lg':'text-slate-500'}`}>Kelola Kunjungan</button>
        <button onClick={()=>setView('wbp')} className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest ${view==='wbp'?'bg-emerald-600 text-white shadow-lg':'text-slate-500'}`}>Data Master WBP</button>
      </div>

      {view === 'kunjungan' ? (
        <div className="glass-card rounded-[2.5rem] overflow-hidden">
          <div className="p-8 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-900/50">
            <h2 className="text-xl font-black">Data Kunjungan Virtual</h2>
            <div className="flex gap-2">
              <button onClick={handlePrint} className="p-3 bg-slate-800 text-white rounded-xl"><Printer size={18}/></button>
            </div>
          </div>
          <div className="p-8">
            <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
              {['Menunggu','Disetujui','Selesai','Ditolak'].map(t => (
                <button key={t} onClick={()=>setActiveTab(t)} className={`px-5 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest whitespace-nowrap transition-all ${activeTab===t?'bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-400':'text-slate-400'}`}>{t}</button>
              ))}
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="text-[9px] font-black uppercase tracking-widest text-slate-400 border-b">
                  <tr><th className="py-4">Pengunjung</th><th>WBP</th><th>Jadwal</th><th className="text-right">Aksi</th></tr>
                </thead>
                <tbody className="divide-y divide-slate-50 dark:divide-slate-800">
                  {filteredData.map(d => (
                    <tr key={d.id} className="text-xs font-bold">
                      <td className="py-4">
                        <div className="flex gap-3">
                          <button onClick={()=>setSelectedPhoto(d.ktpBase64)} className="w-10 h-10 bg-slate-100 rounded-lg overflow-hidden shrink-0"><img src={d.ktpBase64} className="w-full h-full object-cover"/></button>
                          <div><p className="font-black">{d.namaPengunjung}</p><p className="text-[10px] text-slate-500">{d.nik}</p></div>
                        </div>
                      </td>
                      <td><p className="font-black">{d.namaWbp}</p><p className="text-[10px] text-blue-500">{d.hubungan}</p></td>
                      <td><p>{d.tanggalFormat}</p><p className="text-amber-500">{d.sesi}</p></td>
                      <td className="text-right">
                        <div className="flex justify-end gap-2">
                          {activeTab==='Menunggu' && (
                            <>
                              <button onClick={()=>handleUpdateStatus(d.id, 'Disetujui')} className="p-2 bg-emerald-100 text-emerald-600 rounded-lg"><Check size={16}/></button>
                              <button onClick={()=>handleUpdateStatus(d.id, 'Ditolak')} className="p-2 bg-rose-100 text-rose-600 rounded-lg"><X size={16}/></button>
                            </>
                          )}
                          <button onClick={()=>handleDeleteKunjungan(d.id)} className="p-2 text-slate-300 hover:text-rose-500"><Trash2 size={16}/></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        <div className="glass-card rounded-[2.5rem] p-8">
          <h2 className="text-xl font-black mb-6">Database WBP</h2>
          <form onSubmit={handleAddWbp} className="flex gap-3 mb-8">
            <input type="text" value={newWbp.nama} onChange={e=>setNewWbp({...newWbp, nama: e.target.value})} placeholder="Nama WBP" className="flex-1 px-5 py-3 premium-input rounded-xl text-xs font-bold uppercase outline-none" required />
            <button type="submit" className="px-6 py-3 bg-emerald-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest">Tambah</button>
          </form>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {masterWbp.map(w => (
              <div key={w.id} className="p-4 glass-card rounded-2xl flex justify-between items-center">
                <div><p className="font-black text-sm uppercase">{w.nama}</p><p className="text-[10px] text-slate-400">{w.status}</p></div>
                <button onClick={()=>handleDeleteWbp(w.id)} className="p-2 text-slate-300 hover:text-rose-500"><Trash2 size={16}/></button>
              </div>
            ))}
          </div>
        </div>
      )}

      {selectedPhoto && (
        <div className="fixed inset-0 z-[600] flex items-center justify-center p-6 bg-slate-950/90 backdrop-blur-md" onClick={()=>setSelectedPhoto(null)}>
          <img src={selectedPhoto} className="max-w-full max-h-full rounded-2xl shadow-2xl" />
        </div>
      )}

      {confirm.isOpen && (
        <div className="fixed inset-0 z-[700] flex items-center justify-center p-6 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="glass-card p-8 rounded-[2rem] max-w-sm text-center border-rose-500/30">
            <AlertCircle size={40} className="text-rose-600 mx-auto mb-4" />
            <h3 className="text-lg font-black mb-2">Konfirmasi</h3>
            <p className="text-sm font-bold text-slate-500 mb-8">{confirm.msg}</p>
            <div className="flex gap-3">
              <button onClick={()=>setConfirm({isOpen:false,msg:'',onYes:null})} className="flex-1 py-3 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-black uppercase text-[10px]">Batal</button>
              <button onClick={confirm.onYes} className="flex-1 py-3 bg-rose-600 text-white rounded-xl font-black uppercase text-[10px] shadow-lg">Ya, Hapus</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}